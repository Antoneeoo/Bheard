// This script runs in the background.
// For now, it doesn't do anything.
